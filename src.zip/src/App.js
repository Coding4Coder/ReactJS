import React, { Component } from 'react';
import './App.css';

import { BrowserRouter, Routes, Route }  from 'react-router-dom';

import CountNumber from './pages/CountNumber';
import Car from './pages/Car';
import FruitsData from './pages/FruitsData';
import Home from './pages/Home';
import PageNavBar from './Components/PageNavBar';

import Beaches from './pages/Beaches';
import RioChico from './pages/RioChico';
import Sandals from './pages/Sandals';
import UserLogin from './pages/LoginForms/UserLogin';
import Registration from './pages/Registration/Registration';
import Calc from './pages/Calculator/Calc';



const App = () =>{
  return(
      <div className="app-container">
       
        <BrowserRouter>
          <PageNavBar />
         
             <Routes> 
               
                     <Route path="/" element={ <Home /> } />
                    <Route path="index" element={ <Home /> } >
                         <Route path="beaches" element={ <Beaches />} />
                         <Route path="sandals" element={ <Sandals /> } />
                         <Route path="riochico" element={ <RioChico /> } />
                    </Route>

                  <Route path="/car" element={ <Car /> } />
                  <Route path="/counter" element={ <CountNumber /> } />
                  <Route path="/fruits" element={ <FruitsData /> } />

                  <Route path="/login" element={  <UserLogin /> } />
                  <Route path="/registration" element={  <Registration /> } />
                  <Route path="/calc" element={  <Calc /> } />
                 
                 
              </Routes>
           
        </BrowserRouter>  
       

      </div>
  );

}
export default App;