
import React from 'react';

import "../style/global.css";

import sandalsimg from "../img/sandals.jpg";




const Sandals = () => {
    return(
       
            <div className="row">
                <div className="col-sm-2"> 
                <div className="pet-card"><img src={sandalsimg} alt="" className="fix-img" /></div>
                </div>
                <div className="col-sm-10"> 
                <span className="txt">Sandals - Two people in love</span><br />
                Babel is a free and open-source JavaScript transcompiler that is mainly used to convert ECMAScript 2015+ code into a backwards-compatible version of JavaScript that can be run by older JavaScript engines. Babel is a popular tool for using the newest features of the JavaScript programming language. More about Babel will be discussed in our upcoming videos. </div>
                
            </div>
       
    );
}

export default Sandals;