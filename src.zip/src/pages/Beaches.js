
import React from 'react';

import "../style/global.css";
import beaches from "../img/beaches.jpg";




const Beaches = () => {
    return(
       
            <div className="row">
                <div className="col-sm-2"> 
                <div className="pet-card"><img src={beaches} alt="" className="fix-img" /></div>
                </div>
                <div className="col-sm-10"> 
                <span className="txt">Beaches - Discover Romance in Hidden Jamaica</span><br />
                Sandals South Coast, set within a 500-acre nature preserve, is perfectly positioned along a two-mile stretch of unspoiled beach where you can view both the sunrise and the sunset each day. The serenity along this stretch of natural coastline is ideally suited both to relaxation and romance savored beneath the shade of an almond tree.
                </div>
                
            </div>
       
    );
}

export default Beaches;