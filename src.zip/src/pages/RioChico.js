
import React from 'react';

import "../style/global.css";

import riochico from "../img/riochico.jpg";
import classes from "../style/Main.module.css";



const RioChico = () => {
    return(
       
            <div className="row">
                <div className="col-sm-2"> 
                <div className="pet-card"><img src={riochico} alt="" className="fix-img" /></div>
                </div>
                <div className="col-sm-10"> 
                <span className={classes.topTitle}>Rio Chico - Welcome To A World of Privilege And Privacy </span><br />
                
                Pass through the wrought iron gates and begin a magical journey down a quiet winding road, where a sprawling Great Lawn, at once wild and manicured, is rimmed by verdant gardens dotted with streams and waterfalls, ivy-covered bridges, Italian stone statuary and towering palms surrounded by lavish tropical foliage and blooms. Live the fantasy that is Rio Chico.
                </div>
                
            </div>
       
    );
}

export default RioChico;