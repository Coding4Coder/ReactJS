
import React from 'react';
import { Routes, Route, Link, BrowserRouter, useParams, Outlet} from "react-router-dom";

import "../style/global.css";
import beaches from "../img/beaches.jpg";
import sandals from "../img/sandals.jpg";
import riochico from "../img/riochico.jpg";



const Home = () => {

const fixBtm = {
    marginBottom: "2rem",
    paddingBottom: "2rem"
}
    return(
        <React.Fragment>
        <div className="row" style={ fixBtm }>
            <div className="col-sm-4">
                  <div className="pet-card">
                      <h2>Beaches</h2>
                      <img src={beaches} alt="" className="fix-img" />
                            <div className="read-more">
                                <Link to="/index/beaches">Read more</Link>
                          </div>
                      </div>
            </div>
            <div className="col-sm-4">
                    <div className="pet-card">
                    <h2>Sandals</h2>
                        <img src={sandals} alt="" className="fix-img" />
                        <div className="read-more">
                                <Link to="/index/sandals">Read more</Link>
                          </div>
                    </div>
            </div>
            <div className="col-sm-4">
                    <div className="pet-card">
                    <h2>Rio Chico</h2>
                        <img src={riochico} alt="" className="fix-img" />
                        <div className="read-more">
                                <Link to="/index/riochico">Read more</Link>
                          </div>
                    </div>
            </div>
        </div>
        <Outlet />
        
        </React.Fragment>
    );
}

export default Home;