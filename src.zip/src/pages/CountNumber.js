
import React, { useState } from 'react';
import "../style/global.css";

const CountNumber = () => {
    
    const[counter, setCounter] = useState(0)
    let ChangeNumber = () => {
         setCounter(counter + 1);
}

    return(
        <div className="title">
            <h2>useState Hooks</h2>
           <p className="txt">{counter}</p>
           <button className="btn btn-orange" onClick={ChangeNumber}>Change Number</button>
        </div>
    );
}
export default CountNumber;
