
import React, {Fragment} from 'react';
import "../style/global.css";

const FruitsTemplate = (props) => {
        return(
            <React.Fragment>
                <div className="row txt-sm bdr-btm g-0">
                   <div className="col-sm-3">{props.fName}</div>
                   <div className="col-sm-3">{props.fbPrice}</div>
                   <div className="col-sm-3">{props.fsPrice}</div>
                   <div className="col-sm-3">{props.fiStock}</div>
               </div>
            </React.Fragment>
        );
}
export default FruitsTemplate;