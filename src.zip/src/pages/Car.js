
import React, { useState } from 'react';
import "../style/global.css";

const Car = () =>{

    const[car, setCar] = useState({
        brand: "Ford",
        model: "Mustang",
        color: "Silver",
        year: "2015"
    });

   const[currentValue, setCurrentValue] = useState("");

 const displayCurrentValue = (e) => {
    setCurrentValue(e.target.value)
 }
    return (
        <div className="title">
            <p className="txt">Your car name is {car.brand}, It's model {car.model}, color {car.color}, and year {car.year}</p>
            
             <p className="txt"> <input type="text" value={currentValue} onChange={displayCurrentValue} /></p>
                <p className="txt"> Your car is - {currentValue} </p>
            

        </div>
    );
}
export default Car;