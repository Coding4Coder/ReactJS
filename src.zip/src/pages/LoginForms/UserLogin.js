

import React, {useState} from 'react';
import "../../style/global.css";
const UserLogin = () => {

        const[userName, setUserName] = useState("");
        const[userEmail, setuserEmail] = useState("");
        const[userPhone, setuserPhone] = useState("");

        const[newEntries, setNewEntries] = useState([]);


        const formSubmitHandler = (e) => {
            e.preventDefault();
            const newEntries = {loginName:userName, loginEmail:userEmail, loginPhone:userPhone};
            setNewEntries([newEntries]);
        }

    return (
        <div className="row txt-sm bdr-btm g-0">
            <form onSubmit={formSubmitHandler}>
                <div className="login-form">

                   {
                        newEntries.map((entryData) =>
                          <div className="result">
                                <span>User Name : {entryData.loginName}</span>
                                <span>Email :{entryData.loginEmail}</span>
                                <span>Phone : {entryData.loginPhone}</span>
                            </div>
                        )
                      }
                       

                    <input type="text" name="username" id="username" placeholder="User Name" value={userName} 
                    onChange={(e)=>setUserName(e.target.value)} />

                    <input type="text" name="email" id="email" placeholder="Email" value={userEmail} 
                    onChange={(e)=>setuserEmail(e.target.value)}/>

                    <input type="number" name="phonenumber" id="phonenumber" placeholder="Phone Number" value={userPhone} 
                    onChange={(e)=>setuserPhone(e.target.value)}/>

                    <p><button className="btn btn-blue">Submit</button></p>
                </div>

            </form>
    </div>
    );
}
export default UserLogin;