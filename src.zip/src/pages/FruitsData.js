
import React from 'react';

import "../style/global.css";
import FruitsTemplate from './FruitsTemplate';

const FruitsData = () => {

const fruits = [
    {
        name : "Apple",
        buyingPrice :   50,
        sellingPrice : 70,
        inStock :   100
    },
    {
        name : "Mango",
        buyingPrice :   30,
        sellingPrice : 50,
        inStock :   150
    },
    {
        name : "Banana",
        buyingPrice :   20,
        sellingPrice : 40,
        inStock :   500
    }
];


// Get the current Day
let today = new Date();
let currentDay =  today.getDay(); 
let myDay;
switch(currentDay)
    {
    case 0:
        myDay = "Sunday";
        break;
    case 1:
        myDay = "Monday";
        break;
    case 2:
        myDay = "Tuesday";
        break;
    case 3:
        myDay = "Wednesday";
        break;
    case 4:
        myDay = "Thursday";
        break;
    case 5:
        myDay = "Friday";
        break;
    case 6:
        myDay = "Saturday";
        break;
    default:
        myDay = "Looking forward to the Weekend";
    }

//

let fruitesData =  fruits.length + " " + " Fruits";


    return(
        <div className="main-container bdr ">
            <div className="title">{myDay}, { fruitesData }  </div>
               <div className="row txt header g-0">
                   <div className="col-sm-3">Name</div>
                   <div className="col-sm-3">Buying Price</div>
                   <div className="col-sm-3">Selling Price</div>
                   <div className="col-sm-3">Stock</div>
               </div>
               {
                   fruits.map(
                       (fruitsBox) =>
                            <FruitsTemplate 
                            fName={fruitsBox.name}
                            fbPrice={fruitsBox.buyingPrice}
                            fsPrice={fruitsBox.sellingPrice}
                            fiStock={fruitsBox.inStock} 
                            />
                    )
               }
               
        </div>

    );
}
export default FruitsData;