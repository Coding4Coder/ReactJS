

import React from 'react';
import { useState } from 'react';
import "../../style/global.css";

const Registration = () => {

    const[myregistration, setRegistration] = useState({
        firstName: "",
        lastName: "",
        emailAddress: "",
        phoneNumber: "",
        zipcode: "",
        city: ""
    });

    const[newdata, setNewData] = useState([]);

    const inputHandler = (e) => {
        const name = e.target.name;
        const value = e.target.value;
         console.log(name, value);
         setRegistration({...myregistration, [name] : value});
    }

    const formSubmitHandler = (e) => {
        e.preventDefault();
        const newEntries = {...myregistration}
        setNewData([newEntries]);

    }


    return (
        <div className="row txt-sm bdr-btm g-0">
           <form onSubmit={formSubmitHandler}>
               <div className="login-form">

                            {
                                newdata.map((loginData) =>
                                
                                <div className="result">
                                    <span>First Name : {loginData.firstName}</span>
                                    <span>Last Name :{loginData.lastName}</span>
                                    <span>Email : {loginData.emailAddress}</span>
                                    <span>Phone : {loginData.phoneNumber}</span>
                                    <span>Zipcode : {loginData.zipcode}</span>
                                    <span>City : {loginData.city}</span>
                                </div>
                              )
                            }

                   <input  type="text" id="myfirstname" name="firstName" value={myregistration.firstName} placeholder="First Name" onChange={inputHandler} />

                   <input type="text" id="lastname" name="lastName" value={myregistration.lastName} placeholder="Last Name" onChange={inputHandler} />

                   <input  type="text" id="emailaddress" name="emailAddress" value={myregistration.emailAddress} placeholder="Email Address" onChange={inputHandler} />

                   <input  type="text" id="phonenumber" name="phoneNumber" value={myregistration.phoneNumber} placeholder="Phone Number" onChange={inputHandler} />

                   <input  type="text" id="zipcode" name="zipcode" value={myregistration.zipcode} placeholder="Zipcode" onChange={inputHandler} />

                   <input  type="text" id="city" name="city" value={myregistration.city} placeholder="City" onChange={inputHandler} />

                   <p><button className="btn btn-blue">Register</button></p>
               </div>
              
           </form>
        </div>
    );
}

export default Registration;