import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import "../style/global.css";
import "../style/PageNavBar.css";
import logo from "../img/logo.png";

const PageNavBar = () => {
    return (
        <header className="header">
            <div className="row">
                <div className="col-sm-2"> <img src={logo} className="logo" alt="Logo" /> </div>
                <div className="col-sm-10 text-right">
                <nav className="links">
                <ul>
                     <li>
                        <NavLink to="/index">Home</NavLink>
                    </li>
                    <li>
                        <NavLink to="/car">Car</NavLink>
                    </li>
                    <li>
                        <NavLink to="/counter">Counter</NavLink>
                    </li>
                    <li>
                        <NavLink to="/fruits">Fruits</NavLink>
                    </li>
                    <li>
                        <NavLink to="/login">Login</NavLink>
                    </li>
                    <li>
                        <NavLink to="/registration">Registration</NavLink>
                    </li>
                    <li>
                        <NavLink to="/calc">Calculator</NavLink>
                    </li>
                   
                </ul>
             </nav>
                </div>
            </div>

           
        </header>
    );
}
export default PageNavBar;